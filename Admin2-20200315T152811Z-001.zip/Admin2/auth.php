<?php
?>

<?php
session_start();
if(!isset($_SESSION["uid"])){
header("Location:../MyCakeShop/login_form.php");
exit(); }
?>
