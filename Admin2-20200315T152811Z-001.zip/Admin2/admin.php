<?php
require('db.php');
include("auth.php");
/*
Author: Javed Ur Rehman
Website: https://www.allphptricks.com/
*/

 //include auth.php file on all secure pages ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Welcome Home</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body bgcolor="#5a0800">
<div class="form">
<br>
<br>
<br>
<br>
<br>
<br>
<font color="white">
<p><h1>Welcome <?php echo $_SESSION["name"]; ?>!<h1></h1></p>
<p><h2>This is Secure area !</h2></p>
</font>
<br>

<p><a href="dashboard.php"><h2>Dashboard</h2></a></p>
<a href="logout.php"><h2>Logout</h2></a>


<br /><br /><br /><br />
</div>
</body>
</html>
