<?php
 
require('db.php');
include("auth.php"); //include auth.php file on all secure pages ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Dashboard - Admin Page</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body bgcolor="#5a0800">
<text align="center">
<font color="white">
<br>
<br>
<br>
<br>
<h1><p>Welcome to Dashboard <?php echo $_SESSION['name']; ?>!</p>
</font>
<h2>
<p><a href="admin.php">Home</a><p>
<p><a href="insert.php">Insert New Record</a></p>
<p><a href="view.php">View Records</a><p>
<p><a href="#">View Orders</a></p>
<p><a href="logout.php">Logout</a></p></p></h2>
</text>

<br /><br /><br /><br />
</div>
</body>
</html>
