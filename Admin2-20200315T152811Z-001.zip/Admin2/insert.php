<?php
 
include('db.php');
include("auth.php");
if(isset($_POST['submit']))
{
    $product_id = $_POST['product_id'];
    $product_cat = $_POST['product_cat'];
    $product_title = $_POST['product_title'];
    $product_price = $_POST['product_price'];
    $product_desc = $_POST['product_desc'];
    $product_image = $_POST['product_image'];
    $product_keywords = $_POST['product_keywords'];
    $query="INSERT INTO `products` (`product_id`, `product_cat`, `product_title`,`product_price`, `product_desc`, `product_image`,`product_keywords`) VALUES('$product_id','$product_cat','$product_title','$product_price','$product_desc','$product_image','$product_keywords')";    
    if(mysqli_query($con,$query))
    {
    echo "<h2 align='center'><font color='white'>New Record Inserted Successfully</h3>";
    }

    }
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Insert New Record</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body bgcolor="#5a0800">
<h2>
<text align="center">
<p><a href="dashboard.php">Dashboard</a> | <a href="view.php">View Records</a> 
<font color="white">
<text align="center">   
<h1>Insert New Record</h1></font>
<text align="center">
<form name="form" method="post" action=""> 
<p><input type="text" name="product_id" placeholder="Enter product_id" required /></p>
<p><input type="text" name="product_cat" placeholder="Enter product_cat" required /></p>
<p><input type="text" name="product_title" placeholder="Enter product_title" required /></p>
<p><input type="text" name="product_price" placeholder="Enter product_price" required /></p>
<p><input type="text" name="product_desc" placeholder="Enter product_desc" required /></p>
<p><input type="file" name="product_image"   placeholder="Enter product_image" required></p>
<p><input type="text" name="product_keywords" placeholder="Enter product_keywords" required /></p>
<p><input name="submit" type="submit" value="Submit" /></p>
</form>

</div>
</body>
</html>
