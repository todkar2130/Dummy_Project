<?php

require('db.php');
$product_id=$_REQUEST['product_id'];
$query = "DELETE FROM products WHERE product_id=$product_id"; 
$result = mysqli_query($con,$query) or die ( mysqli_error());
header("Location: view.php"); 
?>