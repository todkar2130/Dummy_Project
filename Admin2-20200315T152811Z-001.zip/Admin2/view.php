<?php
include('db.php');
include("auth.php"); 
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>View Records</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body bgcolor="#5a0800">
<p>
<h2><a href="index.php">Home</a> | <a href="insert.php">Insert New Record</a> | <a href="../MyCakeShop/index.php">Logout</a></p></h2>
<font color="white">
<h2>View Records</h2>
<table width="100%" border="1" style="border-collapse:collapse;">
<thead>
<tr>
<th><strong>product_id</strong></th>
<th><strong>product_cat</strong></th>
<th><strong>product_title</strong></th>
<th><strong>product_price</strong></th>
<th><strong>product_desc</strong></th>
<th><strong>product_image</strong></th>
<th><strong>product_keywords</strong></th>
<th><strong>Edit</strong></th>
<th><strong>Delete</strong></th>
</tr>
</thead>
<tbody></font>
<?php
$sel_query="SELECT * FROM products";
$result = mysqli_query($con,$sel_query);
while($row = mysqli_fetch_assoc($result)) { ?>
<tr>
<td align="center"><?php echo $row["product_id"]; ?></td>
<td align="center"><?php echo $row["product_cat"]; ?></td>
<td align="center"><?php echo $row["product_title"]; ?></td>
<td align="center"><?php echo $row["product_price"]; ?></td>
<td align="center"><?php echo $row["product_desc"]; ?></td>
<td align="center"><img  src="../MyCakeShop/product_images/<?php echo $row["product_image"]; ?>" width="200px" height="200px"></td>
<td align="center"><?php echo $row["product_keywords"]; ?></td>
<td align="center" width="100px"><a href="edit.php?product_id=<?php echo $row["product_id"]; ?>"><h2>Edit</h2></a></td>
<td align="center" width="100px"><a href="delete.php?product_id=<?php echo $row["product_id"]; ?>"><h2>Delete</h2></a></td>
</tr>
<?php } ?>
</tbody>
</table>
</body>
</html>
