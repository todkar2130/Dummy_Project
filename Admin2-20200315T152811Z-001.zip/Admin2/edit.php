<?php
 
require('db.php');
include("auth.php");
$product_id=$_REQUEST['product_id'];
$query = "SELECT * from products where product_id='$product_id' "; 
$result = mysqli_query($con, $query) or die ( mysqli_error());
$row = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Update Record</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body bgcolor="#5a0800">
<font size="5" align="center">
<p><a href="dashboard.php">Dashboard</a> | <a href="insert.php">Insert New Record</a> | <a href="logout.php">Logout</a></p>
<h1>Update Record</h1>
<?php
$status = "";
if(isset($_POST['new']) && $_POST['new']==1)
{
    $product_id = $_REQUEST['product_id'];
    $product_cat = $_REQUEST['product_cat'];
    $product_title = $_REQUEST['product_title'];
    $product_price = $_REQUEST['product_price'];
    $product_desc = $_REQUEST['product_desc'];
    $product_image = $_REQUEST['product_image'];
    $product_keywords = $_REQUEST['product_keywords'];
    

$update="UPDATE products SET product_id='$product_id', product_cat='$product_cat',product_title='$product_title',product_price='$product_price',product_desc='$product_desc',product_image='$product_image',product_keywords='$product_keywords' WHERE product_id='$product_id'";
mysqli_query($con, $update) or die(mysqli_error());
$status = "Record Updated Successfully.
 </br></br>
 <a href='view.php'>View Updated Record</a>";
echo '<p style="color:#FF0000;">'.$status.'</p>';
}
else{
echo'
<form method="post" action=""> 
<input type="hidden" name="new" value="1" />
<text align="center">
<input name="product_id" type="hidden" value="$row["product_id"]" />
<p><input type="text" name="product_id" placeholder="Enter product_id" required value="'.$row["product_id"].'" /></p>
<p><input type="text" name="product_cat" placeholder="Enter product_cat" required value="'.$row["product_cat"].'" /></p>
<p><input type="text" name="product_title" placeholder="Enter product_title" required value="'.$row["product_title"].'" /></p>
<p><input type="text" name="product_price" placeholder="Enter product_price" required value="'.$row["product_price"].'" /></p>
<p><input type="text" name="product_desc" placeholder="Enter product_desc" required value="'.$row["product_desc"].'" /></p>
<p><input type="text" name="product_image" placeholder="Enter product_image" required value="'.$row["product_image"].'" /></p>
<p><input type="text" name="product_keywords" placeholder="Enter product_keywords" required value="'.$row["product_keywords"].'" /></p>

<p><input name="submit" type="submit" value="Update" /></p>
</text>

</form>
<br /><br /><br /><br />';

}
?>
</body>
</html>
